package com.lnt.loanApp.controllers;

import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


import com.lnt.loanApp.*;
import com.lnt.loanApp.entities.*;
import com.lnt.loanApp.exceptions.CustomerException;
import com.lnt.loanApp.services.CustomerServices;


public class Controller01 extends TimerTask {

	private CustomerServices service;

	int i=0;
	Timer t=new Timer();
	static Loan loan;
	static int currentAmmount,principleAmount,emi;
	static String aadhaar;

	public static void TimerCancel(Loan ld1,int EMI)
	{
		System.out.println("In constructor");
		principleAmount=Integer.parseInt(ld1.getLoanPrincipleAmount());
		currentAmmount=Integer.parseInt(ld1.getLoanCurrentAmount());
		emi=EMI;
		aadhaar=ld1.getAadhaar();
		System.out.println(aadhaar);
		System.out.println("Deducting from Principle ammount");	
	}
		@Override
		public void run() {
			System.out.println("In run");
			//TimerCancel(ld1,EMI);
			if(currentAmmount!=0) {
				currentAmmount=currentAmmount-emi;
				
				try {
					System.out.println(aadhaar);
					List<Loan> loan=service.getLoanDetails(aadhaar);
					System.out.println(loan);
					for(Loan x:loan)
					{
						System.out.println("Current--->"+x.getLoanCurrentAmount());
						service.updateCurrentAmmount(Integer.toString(currentAmmount), x.getLoanId());
											
						System.out.println("Updated currentammount--->"+currentAmmount);
					}
				} catch (CustomerException e) {
					System.out.println(e);
				}
				
			
				i++;
			}
			else
				  t.cancel();
		}

	
}
class TimerDemo1 {
	  

    // creating timer task, timer
    TimerTask tasknew;
    Timer timer = new Timer();
    public TimerDemo1(Loan ld1,int EMI)
    {
    	Controller01.TimerCancel(ld1,EMI);
  	  tasknew = new Controller01();
    // scheduling the task at interval
    timer.scheduleAtFixedRate(tasknew, 4000,4000);      
    System.out.println("Starting timer");
    }  
 }