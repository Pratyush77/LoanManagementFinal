package com.lnt.loanApp.controllers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.lnt.loanApp.entities.*;
import com.lnt.loanApp.exceptions.*;
import com.lnt.loanApp.services.*;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

//http://localhost:8081/SpringMVC_EmpWebVer5/listAll.do
//@Controller //@Controller is a type of multi action controller
/*@EnableWebMvc*/
public class ControlHrServices{
	
	@Autowired
	private CustomerServices services;
	@RequestMapping("/home_apply")
	public ModelAndView applyHomeLoan() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("home_apply"); //creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Home Loan Application");
		return mAndV;
	}

	@RequestMapping("/vehicle_apply")
	public ModelAndView applyVehicleLoan() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("vehicle_apply"); //creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Vehicle Loan Application");
		return mAndV;
	}
	
	@RequestMapping("/landing")
	public ModelAndView homePage() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("landing"); //creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Home Page");
		return mAndV;
	}
	@RequestMapping("/listAllCustomer")
	public ModelAndView getEmpList() throws CustomerException {
		List<Customer> custList = services.getCustomerList();
		
		
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("ListAllCustomer");
		mAndV.addObject("empList", custList);
		mAndV.addObject("pageTitle","List of all employee");
		return mAndV;
	}
	
	/*@RequestMapping("/account_profile.html")
	public ModelAndView login( HttpServletRequest request,HttpServletResponse response) throws CustomerException, IOException {	
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		response.sendRedirect("http://localhost:8081/LoanManagment/loan/customer.json");
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("customer");
        
		mAndV.addObject("pageTitle","List of all employee");
		return mAndV;
	}*/
    
	@RequestMapping("/done1")
	public ModelAndView register(
			@RequestParam("name") String name,
			@RequestParam("email") String email,
			@RequestParam("city") String city,
			@RequestParam("mobile") String mobile,
			@RequestParam("password") String password
			) throws CustomerException {
		Customer reg=new Customer();
		reg.setName(name);
		reg.setEmail(email);
		reg.setCity(city);
		reg.setMobile(mobile);
		reg.setPassword(password);
		services.insertCustomer(reg);
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("done1"); 
		mAndV.addObject("pageTitle", "Registered");
		return mAndV;
	}
	
	/*@RequestMapping("/done")
	public ModelAndView authenticate(
			@RequestParam("name_of_borrower") String name_of_borrower,
			@RequestParam("gender") String gender,
			@RequestParam("dob") String dob,
			@RequestParam("nationality") String nationality,
			@RequestParam("category") String category,
			@RequestParam("address") String address,
			@RequestParam("pincode") Integer pincode,
			@RequestParam("mobile") String mobile,
			@RequestParam("aadhar") String aadhar,
			@RequestParam("pan") String pan,
			@RequestParam("voter_id") String voter_id,
			@RequestParam("email") String email,
			@RequestParam("apply_as") String apply_as,
			@RequestParam("occupation") String occupation,
			@RequestParam("designation") String designation,
			@RequestParam("name_of_org") String name_of_org,
			@RequestParam("add_of_org") String add_of_org,
			@RequestParam("loan_amount") String loan_amount,
			@RequestParam("tenure") Integer tenure,
			@RequestParam("account_number") String account_number,
			@RequestParam("ifsc_code") String ifsc_code,
			@RequestParam("bank_name") String bank_name,
			@RequestParam("salary") Float salary,
			@RequestParam("loan_type") String loan_type,
			@RequestParam("roi") String roi
			) throws CustomerException {
		CustomerLoan ln=new CustomerLoan();
		CustomerAccount ac=new CustomerAccount();
		Loan ld1=new Loan();
		ln.setNameOfBorrower(name_of_borrower);
		ln.setGender(gender);
		ln.setDob(dob);
		ln.setNationality(nationality);
		ln.setCategory(category);
		ln.setAddress(address);
		ln.setPincode(pincode);
		ln.setMobile(mobile);
		ln.setAadhaarNo(aadhar);
		ln.setPan(pan);
		ln.setVoterId(voter_id);
		ln.setEmail(email);
		ln.setApplyAs(apply_as);
		ln.setOccupation(occupation);
		ln.setDesignation(designation);
		ln.setNameOfOrg(name_of_org);
		ln.setAddOfOrg(add_of_org);
		ln.setLoanAmount(loan_amount);
		ln.setTenure(tenure);
		ac.setAccountNumber(account_number);
		ac.setIfscCode(ifsc_code);
		ac.setBankName(bank_name);
		ac.setSalary(salary);
		
		ld1.setLoanType(loan_type);
		ld1.setLoanPrincipleAmount(loan_amount); 	
		ld1.setLoanCurrentAmount(loan_amount);
	        Date d=new Date();
	      String strDateFormat="dd-MMM-yyyy";
	      SimpleDateFormat objSDF= new SimpleDateFormat(strDateFormat);
	        System.out.println(objSDF.format(d));
	        ld1.setLoanDate(objSDF.format(d));
		List<Loan> x=services.getloanIdList();
		int loanId=0;
		for(Loan y:x)
		{
			loanId=y.getLoanId()+1;
			
		}
		System.out.println(account_number);
		ld1.setLoanId(loanId);
		ld1.setAadhaar(aadhar);   
		ld1.setAccountNumber(account_number);
		ld1.setAccountNumber(account_number);
		int i = Integer.parseInt(roi);
		ld1.setRateOfInterest(i);
		ld1.setTenure(tenure);
		System.out.println("Loan details from controller--->"+ld1);
		ModelAndView mAndV = new ModelAndView();
		if(services.aadhaarVerification(ln))
		{
		services.insertCustomerLoan(ln);
		services.insertCustomerAccount(ac);
		services.insertLoan(ld1);
		
		mAndV.setViewName("success"); 
		}
		else {
			
			mAndV.setViewName("error"); 	
		}
		System.out.println(services.aadhaarVerification(ln));
		
		System.out.println("in authenticate");
		
		mAndV.addObject("pageTitle", "Registered");
		
		return mAndV;
	}
	*/
	
	@RequestMapping("/done2")
	public ModelAndView profile(
			@RequestParam("loan_id") int loan_id,
			@RequestParam("loan_type") String loan_type,
			@RequestParam("loan_principle_amount") String loan_principle_amount,
			@RequestParam("loan_current_amount") String loan_current_amount,
			@RequestParam("loan_date") String loan_date,
			@RequestParam("aadhaar") String aadhaar,
			@RequestParam("account_number") String account_number,
			@RequestParam("rate_of_interest") Integer rate_of_interest,
			@RequestParam("tenure") Integer tenure
			) throws CustomerException {
		Loan ld1=new Loan();
		ld1.setLoanId(loan_id);
		ld1.setLoanType(loan_type);
		ld1.setLoanPrincipleAmount(loan_principle_amount);
		ld1.setLoanCurrentAmount(loan_current_amount);
		ld1.setLoanDate(loan_date);
		ld1.setAadhaar(aadhaar);
		ld1.setAccountNumber(account_number);
		ld1.setRateOfInterest(rate_of_interest);
		ld1.setTenure(tenure);
		services.insertLoan(ld1);
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("done1"); 
		mAndV.addObject("pageTitle", "Registered");
		return mAndV;
	}
	@RequestMapping("/success")
	public ModelAndView success(
			
			) throws CustomerException {
		
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("success"); 
		mAndV.addObject("pageTitle", "Registered");
		return mAndV;
	}
	@RequestMapping("/error")
	public ModelAndView error(
			
			) throws CustomerException {
		System.out.println("Here i am");
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("error"); 
		mAndV.addObject("pageTitle", "Registered");
		return mAndV;
	}
	@RequestMapping("/done5")
	public ModelAndView account(
			
			) throws CustomerException {
		
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("done1"); 
		mAndV.addObject("pageTitle", "Registered");
		return mAndV;
	}
}
