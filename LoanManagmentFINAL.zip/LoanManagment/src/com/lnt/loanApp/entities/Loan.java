package com.lnt.loanApp.entities;

public class Loan{

	private int loanId;
	private String loanType;
	private String loanPrincipleAmount;
	private String loanCurrentAmount;
	private String loanDate;
	private String aadhaar;
	private String accountNumber;
	private int rateOfInterest;
	private int tenure; //Remaining months
	
	
	
	public Loan() {}
		
	public Loan(int loanId, String loanType, String loanPrincipleAmount, String loanCurrentAmount, String loanDate,
			String aadhaar, String accountNumber, int rateOfInterest, int tenure) {
		super();
		this.loanId = loanId;
		this.loanType = loanType;
		this.loanPrincipleAmount = loanPrincipleAmount;
		this.loanCurrentAmount = loanCurrentAmount;
		this.loanDate = loanDate;
		this.aadhaar = aadhaar;
		this.accountNumber = accountNumber;
		this.rateOfInterest = rateOfInterest;
		this.tenure = tenure;
	}
	public int getLoanId() {
		return loanId;
	}
	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public String getLoanPrincipleAmount() {
		return loanPrincipleAmount;
	}
	public void setLoanPrincipleAmount(String loan_principle_amount) {
		this.loanPrincipleAmount = loan_principle_amount;
	}
	public String getLoanCurrentAmount() {
		return loanCurrentAmount;
	}
	public void setLoanCurrentAmount(String loanCurrentAmount) {
		this.loanCurrentAmount = loanCurrentAmount;
	}
	public String getLoanDate() {
		return loanDate;
	}
	public void setLoanDate(String loan_date) {
		this.loanDate = loan_date;
	}
	public String getAadhaar() {
		return aadhaar;
	}
	public void setAadhaar(String aadhaar) {
		this.aadhaar = aadhaar;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", loanType=" + loanType + ", loanPrincipleAmount=" + loanPrincipleAmount
				+ ", loanCurrentAmount=" + loanCurrentAmount + ", loanDate=" + loanDate + ", aadhaar=" + aadhaar
				+ ", accountNumber=" + accountNumber + ", rateOfInterest=" + rateOfInterest + ", tenure=" + tenure
				+ "]";
	}




	
}
