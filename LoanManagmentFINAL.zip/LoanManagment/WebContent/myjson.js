/**
 * _refreshPageData() will call automatically when page loaded Calling
 * _refreshPageData() after every add & Remove of data
 */

var myWebservice = angular.module("myApp", []);

myWebservice
		.controller(
				"ServiceController",
				function($scope, $http) {

					function _refreshPageData() {
						alert("in function data")
						$http( 
								{
									
									method : 'GET',
									url : 'http://localhost:8081/LoanManagment/customer.json'
								}).success(function(data) {
									
									alert("data"+data)
									$scope.posts = data; // response data
									window.location.href = "http://localhost:8081/LoanManagment/account_profile.html";

								//	_refresageData();
									//response.sendRedirect("http://localhost:8081/LoanManagment/account_profile.html");
						});
					}
					function page() {
						alert("in function page")
						$http( 
								{
									
									method : 'GET',
									url : 'http://localhost:8081/LoanManagment/customerLoan.json'
								}).success(function(data) {
									
									alert("data"+data)
									$scope.custom = data; // response data
								
									//response.sendRedirect("http://localhost:8081/LoanManagment/account_profile.html");
						});
						//window.location.href = "http://localhost:8081/LoanManagment/account_profile.html";
					}
					
					/*
					function _refreshPageData() {
						alert("in function")
						$http( 
								{
									
									method : 'GET',
									url : 'http://localhost:8081/LoanManagment/loan/customerLoan.json'
								}).success(function(data) {
									
									alert("data"+data)
									$scope.posts1 = data; // response data

						});
					}*/
/*					$scope.form = {
						countryId : 1,
						countryName : "",
						population : ""

					};
*/
					/*$scope.add = function() {
						// Check url according to your Application name & PORT

						$http(
								{
									method : 'POST',
									url : 'http://localhost:8081/SpringRest020/rest/countries/create/'
											+ $scope.form.countryId
											+ '/'
											+ $scope.form.countryName
											+ '/'
											+ $scope.form.population
								}).success(function(data) {
							alert("DATA ADDED");
							_refreshPageData();

						});

					}
					$scope.remove = function(data) {

						// Check url according to your Application name & PORT
						$http(
								{
									method : 'DELETE',
									url : 'http://localhost:8081/SpringRest020/rest/countries/delete/'
											+ data
								}).success(function(data) {
							alert('Data Deleted')
							_refreshPageData();

						});

					}*/

				});
