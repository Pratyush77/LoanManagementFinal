var emicalculator = angular.module("app", []);
emicalculator.controller("emi", ['$scope', function ($scope) {
    var interestOnly = 0;
    var grandTotal = 0;
    var emi = 0;
    
    $scope.interestRate = function () {
        var interestOnly = $scope.tenure * $scope.monthlyEmi();
        return interestOnly;
    };
    
    $scope.totalAmount = function () {
        grandTotal = Number($scope.principal) + Number($scope.interestRate());
        return grandTotal;
    }
    
    $scope.monthlyEmi = function () {
        ratePerMonth = $scope.interest_rate/(12*100);
        emi = $scope.principal * ratePerMonth * (Math.pow((1 + ratePerMonth), $scope.tenure)) / ((Math.pow((1 + ratePerMonth), $scope.tenure)) - 1);
        return emi;
    }
}]);